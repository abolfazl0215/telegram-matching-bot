module.exports = new Map();
